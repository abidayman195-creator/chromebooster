package com.chromeboost;

import net.minecraftforge.common.ForgeConfigSpec;

public final class BoostConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.IntValue TARGET_FPS;
    public static final ForgeConfigSpec.IntValue MIN_RENDER_DISTANCE;
    public static final ForgeConfigSpec.IntValue CHECK_SECONDS;
    public static final ForgeConfigSpec.BooleanValue CULL_ENTITIES;
    public static final ForgeConfigSpec.IntValue CULL_DISTANCE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        ENABLED = b.comment("Activa el ajuste automático de gráficos.")
                .define("enabled", true);

        TARGET_FPS = b.comment("FPS mínimos que quieres mantener. Si el promedio baja de aquí, se reduce la calidad.")
                .defineInRange("targetFps", 55, 20, 240);

        MIN_RENDER_DISTANCE = b.comment("Distancia de renderizado mínima (chunks) a la que puede bajar el mod.")
                .defineInRange("minRenderDistance", 6, 2, 32);

        CHECK_SECONDS = b.comment("Cada cuántos segundos se mide el promedio de FPS.")
                .defineInRange("checkSeconds", 5, 2, 30);

        CULL_ENTITIES = b.comment("Cuando el mod ya redujo la calidad, no dibuja mobs muy lejanos.")
                .define("cullFarEntities", true);

        CULL_DISTANCE = b.comment("Distancia (bloques) a partir de la cual se omiten mobs lejanos.")
                .defineInRange("cullDistance", 48, 16, 128);

        SPEC = b.build();
    }

    private BoostConfig() {}
}

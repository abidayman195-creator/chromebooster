package com.chromeboost;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.Camera;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Mide los FPS reales y sube o baja un "nivel de ahorro" (0-3).
 * Nivel 0 = tus ajustes originales. Nunca empeora algo que ya tengas más bajo.
 */
@Mod.EventBusSubscriber(modid = ChromeBoost.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class AdaptiveHandler {
    private static final int MAX_LEVEL = 3;
    private static final long DOWNGRADE_COOLDOWN_NS = 60_000_000_000L;

    private static int level = 0;
    private static boolean runtimeEnabled = true;
    private static boolean forcedLevel = false;

    private static long windowStart = 0;
    private static int frames = 0;
    private static int goodWindows = 0;
    private static long noUpgradeUntil = 0;
    private static double lastFps = 0;

    private static Saved saved;

    private AdaptiveHandler() {}

    // ---------------------------------------------------------------- FPS

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        long now = System.nanoTime();
        if (windowStart == 0) {
            windowStart = now;
            frames = 0;
            return;
        }
        frames++;

        long elapsed = now - windowStart;
        long windowNs = BoostConfig.CHECK_SECONDS.get() * 1_000_000_000L;
        if (elapsed < windowNs) return;

        double fps = frames * 1_000_000_000.0 / elapsed;
        windowStart = now;
        frames = 0;
        evaluate(Minecraft.getInstance(), fps, now);
    }

    private static void evaluate(Minecraft mc, double fps, long now) {
        lastFps = fps;

        if (!BoostConfig.ENABLED.get() || !runtimeEnabled) {
            if (level > 0) setLevel(mc, 0);
            return;
        }
        if (forcedLevel) return;

        // Solo medimos jugando: sin pausa, sin menús y con la ventana activa.
        if (mc.level == null || mc.player == null || mc.isPaused()
                || mc.screen != null || !mc.isWindowActive()) {
            goodWindows = 0;
            return;
        }

        int target = BoostConfig.TARGET_FPS.get();

        if (fps < target) {
            goodWindows = 0;
            if (level < MAX_LEVEL) {
                setLevel(mc, level + 1);
                noUpgradeUntil = now + DOWNGRADE_COOLDOWN_NS;
            }
            return;
        }

        // Para volver a subir calidad hay que sobrar margen (o tocar el tope de FPS).
        int cap = mc.options.framerateLimit().get();
        double upThreshold = target + 15;
        if (cap < 260) upThreshold = Math.min(upThreshold, cap - 3);
        upThreshold = Math.max(upThreshold, target + 3);

        if (level > 0 && fps >= upThreshold && now >= noUpgradeUntil) {
            goodWindows++;
            if (goodWindows >= 2) {
                goodWindows = 0;
                setLevel(mc, level - 1);
            }
        } else {
            goodWindows = 0;
        }
    }

    // --------------------------------------------------------- Aplicar nivel

    private static void setLevel(Minecraft mc, int newLevel) {
        newLevel = Math.max(0, Math.min(MAX_LEVEL, newLevel));
        Options o = mc.options;
        if (saved == null) {
            saved = Saved.capture(o);
        }
        level = newLevel;

        int minRd = BoostConfig.MIN_RENDER_DISTANCE.get();

        switch (newLevel) {
            case 0 -> {
                o.renderDistance().set(saved.renderDistance);
                o.simulationDistance().set(saved.simulationDistance);
                o.particles().set(saved.particles);
                o.graphicsMode().set(saved.graphics);
                o.cloudStatus().set(saved.clouds);
                o.ambientOcclusion().set(saved.ambientOcclusion);
                o.entityDistanceScaling().set(saved.entityScale);
                o.biomeBlendRadius().set(saved.biomeBlend);
            }
            case 1 -> {
                o.renderDistance().set(Math.min(saved.renderDistance, Math.max(minRd, 10)));
                o.simulationDistance().set(Math.min(saved.simulationDistance, 10));
                o.particles().set(worse(saved.particles, ParticleStatus.DECREASED));
                o.graphicsMode().set(lower(saved.graphics, GraphicsStatus.FANCY));
                o.cloudStatus().set(lower(saved.clouds, CloudStatus.FAST));
                o.ambientOcclusion().set(saved.ambientOcclusion);
                o.entityDistanceScaling().set(Math.min(saved.entityScale, 0.75));
                o.biomeBlendRadius().set(saved.biomeBlend);
            }
            case 2 -> {
                o.renderDistance().set(Math.min(saved.renderDistance, Math.max(minRd, 8)));
                o.simulationDistance().set(Math.min(saved.simulationDistance, 8));
                o.particles().set(worse(saved.particles, ParticleStatus.DECREASED));
                o.graphicsMode().set(GraphicsStatus.FAST);
                o.cloudStatus().set(CloudStatus.OFF);
                o.ambientOcclusion().set(false);
                o.entityDistanceScaling().set(Math.min(saved.entityScale, 0.6));
                o.biomeBlendRadius().set(Math.min(saved.biomeBlend, 1));
            }
            default -> {
                o.renderDistance().set(Math.min(saved.renderDistance, minRd));
                o.simulationDistance().set(Math.min(saved.simulationDistance, 5));
                o.particles().set(ParticleStatus.MINIMAL);
                o.graphicsMode().set(GraphicsStatus.FAST);
                o.cloudStatus().set(CloudStatus.OFF);
                o.ambientOcclusion().set(false);
                o.entityDistanceScaling().set(Math.min(saved.entityScale, 0.5));
                o.biomeBlendRadius().set(0);
            }
        }

        if (newLevel == 0) {
            saved = null; // la próxima vez se vuelve a capturar lo que tengas
        }
    }

    private static ParticleStatus worse(ParticleStatus current, ParticleStatus limit) {
        return current.ordinal() >= limit.ordinal() ? current : limit;
    }

    private static GraphicsStatus lower(GraphicsStatus current, GraphicsStatus limit) {
        return current.ordinal() <= limit.ordinal() ? current : limit;
    }

    private static CloudStatus lower(CloudStatus current, CloudStatus limit) {
        return current.ordinal() <= limit.ordinal() ? current : limit;
    }

    private record Saved(int renderDistance, int simulationDistance, ParticleStatus particles,
                         GraphicsStatus graphics, CloudStatus clouds, boolean ambientOcclusion,
                         double entityScale, int biomeBlend) {
        static Saved capture(Options o) {
            return new Saved(
                    o.renderDistance().get(),
                    o.simulationDistance().get(),
                    o.particles().get(),
                    o.graphicsMode().get(),
                    o.cloudStatus().get(),
                    o.ambientOcclusion().get(),
                    o.entityDistanceScaling().get(),
                    o.biomeBlendRadius().get());
        }
    }

    // ---------------------------------------------------- Culling de mobs

    @SubscribeEvent
    public static void onRenderLiving(RenderLivingEvent.Pre<?, ?> event) {
        if (level < 1 || !BoostConfig.CULL_ENTITIES.get()) return;

        LivingEntity entity = event.getEntity();
        if (entity instanceof Player) return;

        Camera camera = Minecraft.getInstance().gameRenderer.getMainCamera();
        double max = BoostConfig.CULL_DISTANCE.get();
        if (camera.getPosition().distanceToSqr(entity.getX(), entity.getY(), entity.getZ()) > max * max) {
            event.setCanceled(true);
        }
    }

    // ------------------------------------------------ Restaurar al salir

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        Minecraft mc = Minecraft.getInstance();
        if (level > 0) setLevel(mc, 0);
        forcedLevel = false;
        goodWindows = 0;
        windowStart = 0;
    }

    // ------------------------------------------------------------ Comandos

    @SubscribeEvent
    public static void onCommands(RegisterClientCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("chromeboost")
                .then(Commands.literal("status").executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal(String.format(
                            "ChromeBoost: nivel %d/%d, %.0f FPS (objetivo %d), %s%s",
                            level, MAX_LEVEL, lastFps, BoostConfig.TARGET_FPS.get(),
                            runtimeEnabled && BoostConfig.ENABLED.get() ? "activo" : "pausado",
                            forcedLevel ? ", nivel fijado a mano" : "")), false);
                    return 1;
                }))
                .then(Commands.literal("toggle").executes(ctx -> {
                    runtimeEnabled = !runtimeEnabled;
                    ctx.getSource().sendSuccess(() -> Component.literal(
                            "ChromeBoost " + (runtimeEnabled ? "activado" : "pausado")), false);
                    return 1;
                }))
                .then(Commands.literal("level")
                        .then(Commands.argument("n", IntegerArgumentType.integer(0, MAX_LEVEL)).executes(ctx -> {
                            int n = IntegerArgumentType.getInteger(ctx, "n");
                            forcedLevel = true;
                            setLevel(Minecraft.getInstance(), n);
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                    "ChromeBoost: nivel fijado en " + n + " (usa /chromeboost auto para volver al modo automático)"), false);
                            return 1;
                        })))
                .then(Commands.literal("auto").executes(ctx -> {
                    forcedLevel = false;
                    ctx.getSource().sendSuccess(() -> Component.literal("ChromeBoost: modo automático"), false);
                    return 1;
                })));
    }
}

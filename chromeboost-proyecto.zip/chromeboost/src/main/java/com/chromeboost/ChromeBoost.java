package com.chromeboost;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

/**
 * ChromeBoost: mod solo de cliente que ajusta los gráficos automáticamente
 * para mantener los FPS estables en equipos modestos (p. ej. Chromebooks).
 */
@Mod(ChromeBoost.MOD_ID)
public class ChromeBoost {
    public static final String MOD_ID = "chromeboost";

    public ChromeBoost() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, BoostConfig.SPEC);
    }
}
